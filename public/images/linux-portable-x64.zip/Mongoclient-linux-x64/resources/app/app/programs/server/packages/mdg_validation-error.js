(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var ValidationError;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/mdg_validation-error/validation-error.js                                                        //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
/* global ValidationError:true */                                                                           //
                                                                                                            //
// This is exactly what comes out of SS.                                                                    //
var errorPattern = [{                                                                                       // 4
  name: String,                                                                                             // 5
  type: String,                                                                                             // 6
  details: Match.Optional(Object)                                                                           // 7
}];                                                                                                         //
                                                                                                            //
ValidationError = (function (_Meteor$Error) {                                                               // 10
  babelHelpers.inherits(_class, _Meteor$Error);                                                             //
                                                                                                            //
  function _class(errors) {                                                                                 // 11
    var message = arguments.length <= 1 || arguments[1] === undefined ? 'Validation Failed' : arguments[1];
    babelHelpers.classCallCheck(this, _class);                                                              //
                                                                                                            //
    check(errors, errorPattern);                                                                            // 12
    check(message, String);                                                                                 // 13
                                                                                                            //
    return _Meteor$Error.call(this, ValidationError.ERROR_CODE, message, errors);                           // 15
  }                                                                                                         //
                                                                                                            //
  return _class;                                                                                            //
})(Meteor.Error);                                                                                           //
                                                                                                            //
// If people use this to check for the error code, we can change it                                         //
// in future versions                                                                                       //
ValidationError.ERROR_CODE = 'validation-error';                                                            // 21
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mdg:validation-error'] = {
  ValidationError: ValidationError
};

})();

//# sourceMappingURL=mdg_validation-error.js.map
