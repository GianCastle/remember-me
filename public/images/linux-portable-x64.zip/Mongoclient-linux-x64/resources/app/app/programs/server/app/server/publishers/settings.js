(function(){/**
 * Created by RSercan on 19.1.2016.
 */
Meteor.publish('settings', function () {
    return Settings.find();
});
}).call(this);

//# sourceMappingURL=settings.js.map
