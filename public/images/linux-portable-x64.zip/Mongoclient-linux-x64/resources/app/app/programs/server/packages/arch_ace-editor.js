(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['arch:ace-editor'] = {};

})();

//# sourceMappingURL=arch_ace-editor.js.map
