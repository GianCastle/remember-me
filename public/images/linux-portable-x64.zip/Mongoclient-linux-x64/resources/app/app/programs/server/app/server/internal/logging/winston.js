(function(){/**
 * Created by RSercan on 5.3.2016.
 */
LOGGER = Meteor.npmRequire('winston');
}).call(this);

//# sourceMappingURL=winston.js.map
