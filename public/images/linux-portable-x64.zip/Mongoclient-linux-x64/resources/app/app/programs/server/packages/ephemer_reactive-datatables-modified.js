(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ephemer:reactive-datatables-modified'] = {};

})();

//# sourceMappingURL=ephemer_reactive-datatables-modified.js.map
