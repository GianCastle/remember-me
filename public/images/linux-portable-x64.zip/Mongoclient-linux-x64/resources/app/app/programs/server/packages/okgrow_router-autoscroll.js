(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Promise = Package.promise.Promise;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['okgrow:router-autoscroll'] = {};

})();

//# sourceMappingURL=okgrow_router-autoscroll.js.map
