(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Random = Package.random.Random;

/* Package-scope variables */
var Electrify, SockJS;

(function(){

//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
// packages/arboleya_electrify/meteor/index.js                                  //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////
                                                                                //
Electrify = {};                                                                 // 1
                                                                                // 2
var callbacks = {};                                                             // 3
var socket;                                                                     // 4
var where;                                                                      // 5
                                                                                // 6
Meteor.startup(function(){                                                      // 7
                                                                                // 8
  if(Meteor.isServer) {                                                         // 9
    where = 'server';                                                           // 10
    SockJS = Npm.require('sockjs-client');                                      // 11
    Meteor.methods({                                                            // 12
      'electrify.get.socket.port': function(){                                  // 13
        return process.env.SOCKET_PORT || null;                                 // 14
      }                                                                         // 15
    });                                                                         // 16
                                                                                // 17
    connect(process.env.SOCKET_PORT);                                           // 18
  }                                                                             // 19
                                                                                // 20
  if(Meteor.isClient) {                                                         // 21
    where = 'client';                                                           // 22
    SockJS = SockJS || window.SockJS;                                           // 23
    Meteor.call('electrify.get.socket.port', [], function(error, port){         // 24
      connect(port);                                                            // 25
    });                                                                         // 26
  }                                                                             // 27
                                                                                // 28
});                                                                             // 29
                                                                                // 30
function log(){                                                                 // 31
  var args = Array.prototype.slice.call(arguments);                             // 32
  console.log('electrify:meteor:index@'+ where +':', args.join(' '));           // 33
}                                                                               // 34
                                                                                // 35
function connect(port){                                                         // 36
                                                                                // 37
  if(!port) {                                                                   // 38
    log([                                                                       // 39
      'cannot initialize connection. Did you `npm install -g electrify`?',      // 40
      'install it and try running your meteor app with `electrify` npm command'
    ].join('\n'));                                                              // 42
    return;                                                                     // 43
  }                                                                             // 44
                                                                                // 45
  socket = new SockJS('http://127.0.0.1:' + port + '/electrify');               // 46
                                                                                // 47
  socket.onopen = function() {                                                  // 48
    log('connection is open');                                                  // 49
    fire_ready_callbacks();                                                     // 50
  };                                                                            // 51
                                                                                // 52
  socket.onmessage = function(e) {                                              // 53
    var packet = JSON.parse(e.data);                                            // 54
    var done;                                                                   // 55
                                                                                // 56
    if((done = callbacks[packet.handshake])) {                                  // 57
      callbacks[packet.handshake] = null;                                       // 58
      delete callbacks[packet.handshake];                                       // 59
      done.apply(null, [].concat(packet.error, packet.args));                   // 60
    }                                                                           // 61
    else                                                                        // 62
      done.apply(null, [                                                        // 63
        'No callback defined for handshake `'+ packet.handshake +'`'            // 64
      ]);                                                                       // 65
  };                                                                            // 66
                                                                                // 67
  socket.onclose = function() {                                                 // 68
    log('closing socket connection');                                           // 69
  };                                                                            // 70
}                                                                               // 71
                                                                                // 72
var startup_callbacks = {                                                       // 73
  server: [],                                                                   // 74
  client: []                                                                    // 75
};                                                                              // 76
                                                                                // 77
Electrify.startup = function(ready){                                            // 78
  var where = Meteor.isServer ? 'server' : 'client';                            // 79
  startup_callbacks[where].push(ready);                                         // 80
};                                                                              // 81
                                                                                // 82
function fire_ready_callbacks(){                                                // 83
  var where = Meteor.isServer ? 'server' : 'client';                            // 84
  _.each(startup_callbacks[where], function(ready) {                            // 85
    ready();                                                                    // 86
  });                                                                           // 87
  startup_callbacks[where] = [];                                                // 88
}                                                                               // 89
                                                                                // 90
Electrify.call = function(method, args, done) {                                 // 91
                                                                                // 92
  if(!(done instanceof Function))                                               // 93
    throw new Error('Third argument to `Electrify.call()` must be a funciton');
                                                                                // 95
  if(!socket) {                                                                 // 96
    var msg = 'Cannot call methods, socket connection not initialized';         // 97
    console.warn(msg);                                                          // 98
    setTimeout(function(){ done(new Error(msg)); }, 1);                         // 99
    return;                                                                     // 100
  }                                                                             // 101
                                                                                // 102
  var packet = {                                                                // 103
    handshake: Random.id(),                                                     // 104
    method: method,                                                             // 105
    args: args                                                                  // 106
  };                                                                            // 107
                                                                                // 108
  callbacks[packet.handshake] = done;                                           // 109
  socket.send(JSON.stringify(packet));                                          // 110
};                                                                              // 111
                                                                                // 112
//////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['arboleya:electrify'] = {
  Electrify: Electrify
};

})();

//# sourceMappingURL=arboleya_electrify.js.map
